#!/bin/sh

mysql -uroot < create-mysql-db.sql